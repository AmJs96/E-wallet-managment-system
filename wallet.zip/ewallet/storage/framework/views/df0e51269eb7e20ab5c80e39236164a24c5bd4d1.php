<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>
<?php
$balance = Session::get('balance');
$totalWithdrawn = \App\Models\Transaction::sum('withdraw');
$currentBalance = $balance - $totalWithdrawn;

?>
<div class="nav" style="background-color: red;height: 75px;">
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('home')); ?>">Home</a>
    </div>
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('addTransaction')); ?>">Add Transaction</a>
    </div>
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('viewTransaction')); ?>">View
            Transaction</a>
    </div>
    <div style="width: 20%;float: right;margin-left: 30px;">
        <p style="float: right;color: white!important;"><?php echo Session::get('user_name')?>
            <br>Balance:(<?php echo $currentBalance?>)<br><a href="<?php echo e(route('signout')); ?>">Sign out</a></p>
        <p></p>

    </div>
</div>
<div style="clear: left"></div>
<div class="form" style="width: 30%;margin: 0 auto;margin-top: 100px;">
    <fieldset>
        <legend>Add Transaction</legend>
        <?php
        if(Session::get('success') != '')
        {
        ?>
        <p style=" color: blue ">Data has been saved successfully</p>
        <?php
        Session::put('success','');
        }
        ?>
        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('transactionSave')); ?>">

            <table>
                <tr>
                    <td>Balance</td>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <td><input readonly id="balance" value="<?php echo $currentBalance ?>" type="text" name="balance">
                    </td>
                </tr>
                <tr>
                    <td>Withdraw</td>
                    <td><input required type="text" oninput="remaining_cal(this.value)" name="withdraw" id="withdraw"></td>
                </tr>
                <tr>
                    <td>Remaining Amount</td>
                    <td><input type="text" readonly name="remaining_amount" id="remaining_amount"></td>
                </tr>
                <tr>
                    <td>Date</td>
                    <td><input type="text" value="<?php echo date('d-m-Y')?>" name="date"></td>
                </tr>

                <tr>
                    <td></td>
                    <td><input type="submit" value="submit" name="Submit"></td>
                </tr>
            </table>
        </form>
    </fieldset>

</div>

<div id="gender_info_show">

</div>
<img style="display: none;position: fixed;z-index: 1;width: 50px;height: 50px;" src="<?php echo e(asset('images/loader.gif')); ?>"
     id="loader" alt="#">

<script>
    function remaining_cal(withdraw) {
        var balance = $('#balance').val();
        $('#remaining_amount').val(Number(balance) - Number(withdraw));

    }

    function load_gender_info(gender) {
        //alert(gender);
        $('#loader').show();
        $_token = "<?php echo e(csrf_token()); ?>";
        $.ajax({
            headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')},
            url: "<?php echo e(route('load_gender_info')); ?>",
            type: 'POST',
            cache: false,
            data: {'_token': $_token, 'gender': gender}, //see the $_token
            datatype: 'html',
            beforeSend: function () {
            },
            success: function (data) {
                // alert(data);
                document.getElementById('gender_info_show').innerHTML = data;
                $('#loader').hide();

            }
        });
    }
</script>

</body>
</html>
<?php /**PATH G:\xamppphp7.3\htdocs\mylaravel\resources\views/add_transaction.blade.php ENDPATH**/ ?>