<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Session;

class LoginController extends Controller
{
    //
    public function login(Request  $request)
    {

        $users=DB::table('users')
            ->where('email',$request->email)
            ->where('password',$request->password)
            ->get();

        if(count($users)>0)
        {
            $user_name='';
            $id='';
            $email='';
            $image='';
            $balance='';
            foreach ($users as $user)
            {
                $user_name=$user->name;
                $email=$user->email;
                $id=$user->id;
                $image=$user->image;
                $balance=$user->balance;
            }
            $succes="Signed in successfully";
            $request->session()->put('user_name',$user_name);
            $request->session()->put('balance',$balance);
            return view('home',compact('succes'));

        }else{
            $failed="Signed in successfully";
            return view('login',compact('failed'));
        }


    }
    public function signout()
    {
        Session::flush();
        return view('login');
    }
}
