<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>
<?php
$balance = Session::get('balance');
$totalWithdrawn = \App\Models\Transaction::sum('withdraw');
$currentBalance = $balance - $totalWithdrawn;

?>
<div class="nav" style="background-color: red;height: 75px;">
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="{{route('home')}}">Home</a>
    </div>
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="{{route('addTransaction')}}">Add Transaction</a>
    </div>
    <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
        <a style="text-decoration: none;color: white!important;" href="{{route('viewTransaction')}}">View
            Transaction</a>
    </div>
    <div style="width: 20%;float: right;margin-left: 30px;">
        <p style="float: right;color: white!important;"><?php echo Session::get('user_name')?>
            <br>Balance:(<?php echo $currentBalance?>)<br><a href="{{route('signout')}}">Sign out</a></p>
        <p></p>

    </div>
</div>
<fieldset>
    <legend>View Transaction</legend>
    <?php
    if(Session::get('success') != '')
    {
    ?>
    <p style=" color: blue ">Data has been deleted successfully</p>
    <?php
    Session::put('success','');
    }
    ?>
    <table border="1" style="border-collapse: collapse;width: 50%;margin: 0 auto " >
        <tr>
            <td>#</td>
            <td>Balance</td>
            <td>Withdraw</td>
            <td>Date</td>
            <td>Remaining</td>
            <td>Delete</td>
        </tr>

    <?php
        $sl=1;
    foreach ($transactions as $transaction)
        {
            ?>
        <tr>
            <td><?php echo $sl++?></td>
            <td><?php echo $transaction->balance?></td>
            <td><?php echo $transaction->withdraw?></td>
            <td><?php echo date('d-m-Y',strtotime($transaction->date))?></td>
            <td><?php echo $transaction->remaining_amount?></td>
            <td><a onclick="return confirm('Do you want to delete?')" href="{{route('deleteTransaction',$transaction->id)}}">Delete</a></td>
        </tr>
    <?php
        }
    ?>
    </table>


</fieldset>
</body>
</html>
