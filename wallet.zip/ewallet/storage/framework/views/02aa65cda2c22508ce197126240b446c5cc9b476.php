<h1>Female Info Form</h1>
<p>Name:Rahima</p>
<p>Age:45</p>
<p>Status:Employee</p>
<?php /**PATH F:\xampp7.3\htdocs\mylaravel\resources\views/female_info_view.blade.php ENDPATH**/ ?>