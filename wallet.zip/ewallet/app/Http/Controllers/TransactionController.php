<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;


class TransactionController extends Controller
{
    //
    public function addTransaction()
    {
        return view('add_transaction');
    }

    public function home()
    {
        return view('home');
    }

    public function viewTransaction()
    {
        $transactions = Transaction::all();
        return view('view_transaction', compact('transactions'));
    }


    public function transactionSave(Request $request)
    {

        $transaction = new Transaction();

        $transaction->balance = $request->balance;
        $transaction->withdraw = $request->withdraw;
        $transaction->remaining_amount = $request->remaining_amount;
        $transaction->date = date('Y-m-d', strtotime($request->date));
        $transaction->save();
        $request->session()->put('success', 'Data has been saved successfully');
        return redirect()->route('addTransaction')->with('success', "Data has been saved successfully");
    }

    public function deleteTransaction($id)
    {
        $data = Transaction::findOrFail($id);
        $data->delete();
        $transactions = Transaction::all();
        return view('view_transaction', compact('transactions'));
    }

}
