<?php

if ($_POST['pay']) {
    $amount = $_POST['amount'];

    function cashback($amount)
    {
        $balance = $amount + 0.50;

        return $balance;
    }
    $balance = cashback($amount);

    echo $balance;
}
