<div style="width: 30%;margin: 0 auto;margin-top: 100px;">
    <form method="post" action="<?php echo e(route('login')); ?>">
        <table>
            <tr>
                <td>User Name</td>
               <td>
                   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                   <input type="email" name="email" id="email" >
               </td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" id="password" ></td>
            </tr>
            <tr>
                <td></td>
                <td>   <input type="submit" name="submit_button" value="Login" id="submit_button" ></td>
            </tr>
        </table>

    </form>
</div>
<?php /**PATH F:\xampp7.3\htdocs\mylaravel\resources\views/login.blade.php ENDPATH**/ ?>