<h1>Male Info Form</h1>
<p>Name:Karim Uddin</p>
<p>Age:45</p>
<p>Status:Employee</p>
<?php /**PATH F:\xampp7.3\htdocs\mylaravel\resources\views/male_info_view.blade.php ENDPATH**/ ?>