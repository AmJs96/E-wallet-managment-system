<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>



    </head>
    <body>
        <a href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('contact-us')); ?>">Contact Us</a>
        <a href="<?php echo e(route('view-contact-us')); ?>">Contact Us</a>

		<h1> This is the Home Page</h1>
    <p style="float: right"><?php echo  $_SESSION['user_name']?>(<a href="">Sign oUt</a>)</p>
    </body>
</html>
<?php /**PATH F:\xampp7.3\htdocs\mylaravel\resources\views/home.blade.php ENDPATH**/ ?>