<?php

$amount = $_GET['amount'];


echo 'Successfully top up ' . $amount . ' RM';
