<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\TransactionController;

Route::get('/', function () {
    return view('login');
});

Route::get('/home', [HomeController::class, 'home'])->name('home');
Route::get('/view-contact-us', [HomeController::class, 'view_contact_us'])->name('view-contact-us');


Route::get('/contact-us', [HomeController::class, 'contact_us'])->name('contact-us');
Route::post('/datasave', [HomeController::class, 'datasave'])->name('datasave');
Route::post('/load_gender_info', [HomeController::class, 'load_gender_info'])->name('load_gender_info');
Route::get('/addTransaction', [TransactionController::class, 'addTransaction'])->name('addTransaction');
Route::get('/viewTransaction', [TransactionController::class, 'viewTransaction'])->name('viewTransaction');
Route::get('/signout', [LoginController::class, 'signout'])->name('signout');
Route::post('/transactionSave', [TransactionController::class, 'transactionSave'])->name('transactionSave');

Route::get('/deleteTransaction/{id}', [TransactionController::class, 'deleteTransaction'])->name('deleteTransaction');



Route::post('/login', [LoginController::class, 'login'])->name('login');


