<!DOCTYPE html>
<?php
//use Session;
use Illuminate\Support\Facades\Session;
?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Wallet Management</title>
    </head>
    <body>
    <?php
    $balance = Session::get('balance');
    $totalWithdrawn = \App\Models\Transaction::sum('withdraw');
    $currentBalance = $balance - $totalWithdrawn;

    ?>
    <div class="nav" style="background-color: red;height: 75px;">
        <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
            <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('home')); ?>">Home</a>
        </div>
        <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
            <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('addTransaction')); ?>">Add Transaction</a>
        </div>
        <div style="width: 20%;float: left;margin-left: 30px;padding-top: 30px;">
            <a style="text-decoration: none;color: white!important;" href="<?php echo e(route('viewTransaction')); ?>">View
                Transaction</a>
        </div>
        <div style="width: 20%;float: right;margin-left: 30px;">
            <p style="float: right;color: white!important;"><?php echo Session::get('user_name')?>
                <br>Balance:(<?php echo $currentBalance?>)<br><a href="<?php echo e(route('signout')); ?>">Sign out</a></p>
            <p></p>

        </div>
    </div>
    <div style="clear: left">
        <h3 style="text-align: center;margin-top: 100px;">E wallet management</h3>
    </div>






    </body>
</html>
<?php /**PATH G:\xamppphp7.3\htdocs\mylaravel\resources\views/home.blade.php ENDPATH**/ ?>