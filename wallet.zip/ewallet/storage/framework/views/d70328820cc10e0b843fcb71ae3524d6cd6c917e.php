<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>
<h1></h1>
<a href="<?php echo e(route('home')); ?>">Home</a>
<a href="<?php echo e(route('contact-us')); ?>">Contact Us</a>

<h1> This is the Contact Us Page</h1>
<form method="post" enctype="multipart/form-data" action="<?php echo e(route('datasave')); ?>">
    <table>
        <tr>
            <td>Name</td>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>fdfdf</td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="text" name="password"></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td>
                <select type="text" onchange="load_gender_info(this.value)" name="gender_info" id="gender_info">
                    <option disabled></option>
                    <option>Male</option>
                    <option>Female</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Image</td>
            <td><input type="file" name="image"></td>
        </tr>
        <tr>
            <td>Mobile</td>
            <td><input type="submit" value="submit" name="mobile"></td>
        </tr>
    </table>
</form>
<div id="gender_info_show">

</div>
<img style="display: none;position: fixed;z-index: 1;width: 50px;height: 50px;" src="<?php echo e(asset('images/loader.gif')); ?>" id="loader" alt="#">

<script>
    function load_gender_info(gender)
    {
        //alert(gender);
        $('#loader').show();
        $_token = "<?php echo e(csrf_token()); ?>";
        $.ajax({
            headers: {'X-CSRF-Token': $('meta[name=_token]').attr('content')},
            url: "<?php echo e(route('load_gender_info')); ?>",
            type: 'POST',
            cache: false,
            data: {'_token': $_token,'gender':gender}, //see the $_token
            datatype: 'html',
            beforeSend: function () {
            },
            success: function (data) {
                // alert(data);
                document.getElementById('gender_info_show').innerHTML = data;
                $('#loader').hide();

            }
        });
    }
</script>

</body>
</html>
<?php /**PATH G:\xamppphp7.3\htdocs\mylaravel\resources\views/contact_us.blade.php ENDPATH**/ ?>